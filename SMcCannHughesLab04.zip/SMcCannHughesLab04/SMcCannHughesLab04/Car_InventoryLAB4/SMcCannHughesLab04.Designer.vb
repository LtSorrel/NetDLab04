﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CarInventoryForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ListViewGroup1 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("New", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup2 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("ID", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup3 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("Make", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup4 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("Model", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup5 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("Year", System.Windows.Forms.HorizontalAlignment.Left)
        Dim ListViewGroup6 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("Price", System.Windows.Forms.HorizontalAlignment.Left)
        Me.lblMake = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblNew = New System.Windows.Forms.Label()
        Me.cbNew = New System.Windows.Forms.CheckBox()
        Me.cmbMake = New System.Windows.Forms.ComboBox()
        Me.tbModel = New System.Windows.Forms.TextBox()
        Me.cmbYear = New System.Windows.Forms.ComboBox()
        Me.tbPrice = New System.Windows.Forms.TextBox()
        Me.lvwCars = New System.Windows.Forms.ListView()
        Me.colNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttCarInventory = New System.Windows.Forms.ToolTip(Me.components)
        Me.lblResults = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblMake
        '
        Me.lblMake.AutoSize = True
        Me.lblMake.Location = New System.Drawing.Point(93, 25)
        Me.lblMake.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(50, 17)
        Me.lblMake.TabIndex = 0
        Me.lblMake.Text = "&Make :"
        Me.lblMake.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.Location = New System.Drawing.Point(91, 58)
        Me.lblModel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(54, 17)
        Me.lblModel.TabIndex = 1
        Me.lblModel.Text = "M&odel :"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.Location = New System.Drawing.Point(100, 90)
        Me.lblYear.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(46, 17)
        Me.lblYear.TabIndex = 2
        Me.lblYear.Text = "&Year :"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Location = New System.Drawing.Point(97, 123)
        Me.lblPrice.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(48, 17)
        Me.lblPrice.TabIndex = 3
        Me.lblPrice.Text = "&Price :"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblNew
        '
        Me.lblNew.AutoSize = True
        Me.lblNew.Location = New System.Drawing.Point(104, 153)
        Me.lblNew.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNew.Name = "lblNew"
        Me.lblNew.Size = New System.Drawing.Size(39, 17)
        Me.lblNew.TabIndex = 4
        Me.lblNew.Text = "&New:"
        Me.lblNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cbNew
        '
        Me.cbNew.AutoSize = True
        Me.cbNew.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cbNew.Location = New System.Drawing.Point(155, 153)
        Me.cbNew.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbNew.Name = "cbNew"
        Me.cbNew.Size = New System.Drawing.Size(18, 17)
        Me.cbNew.TabIndex = 4
        Me.ttCarInventory.SetToolTip(Me.cbNew, "Please Indicate Whether Or Not Your Car Is New")
        Me.cbNew.UseVisualStyleBackColor = True
        '
        'cmbMake
        '
        Me.cmbMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMake.FormattingEnabled = True
        Me.cmbMake.Items.AddRange(New Object() {"Ford", "Mustang", "Dodge", "Chevrolet", "Chrysler", "Audi", "Bently", "Cadillac", "GMC"})
        Me.cmbMake.Location = New System.Drawing.Point(155, 21)
        Me.cmbMake.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbMake.Name = "cmbMake"
        Me.cmbMake.Size = New System.Drawing.Size(160, 24)
        Me.cmbMake.TabIndex = 0
        Me.ttCarInventory.SetToolTip(Me.cmbMake, "Please Enter Your Cars Make")
        '
        'tbModel
        '
        Me.tbModel.Location = New System.Drawing.Point(155, 54)
        Me.tbModel.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tbModel.Name = "tbModel"
        Me.tbModel.Size = New System.Drawing.Size(160, 22)
        Me.tbModel.TabIndex = 1
        Me.ttCarInventory.SetToolTip(Me.tbModel, "Please Enter Your Cars Model")
        '
        'cmbYear
        '
        Me.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbYear.FormattingEnabled = True
        Me.cmbYear.Items.AddRange(New Object() {"2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", ""})
        Me.cmbYear.Location = New System.Drawing.Point(155, 86)
        Me.cmbYear.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cmbYear.Name = "cmbYear"
        Me.cmbYear.Size = New System.Drawing.Size(160, 24)
        Me.cmbYear.TabIndex = 2
        Me.ttCarInventory.SetToolTip(Me.cmbYear, "Please Enter Your Cars Year")
        '
        'tbPrice
        '
        Me.tbPrice.Location = New System.Drawing.Point(155, 119)
        Me.tbPrice.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tbPrice.Name = "tbPrice"
        Me.tbPrice.Size = New System.Drawing.Size(160, 22)
        Me.tbPrice.TabIndex = 3
        Me.ttCarInventory.SetToolTip(Me.tbPrice, "Please Enter The Price Of Your Car")
        '
        'lvwCars
        '
        Me.lvwCars.CheckBoxes = True
        Me.lvwCars.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNew, Me.colID, Me.colMake, Me.colYear, Me.colPrice})
        Me.lvwCars.FullRowSelect = True
        ListViewGroup1.Header = "New"
        ListViewGroup1.Name = "New"
        ListViewGroup2.Header = "ID"
        ListViewGroup2.Name = "ID"
        ListViewGroup3.Header = "Make"
        ListViewGroup3.Name = "Make"
        ListViewGroup4.Header = "Model"
        ListViewGroup4.Name = "Model"
        ListViewGroup5.Header = "Year"
        ListViewGroup5.Name = "Year"
        ListViewGroup6.Header = "Price"
        ListViewGroup6.Name = "Price"
        Me.lvwCars.Groups.AddRange(New System.Windows.Forms.ListViewGroup() {ListViewGroup1, ListViewGroup2, ListViewGroup3, ListViewGroup4, ListViewGroup5, ListViewGroup6})
        Me.lvwCars.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwCars.HideSelection = False
        Me.lvwCars.Location = New System.Drawing.Point(13, 194)
        Me.lvwCars.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.lvwCars.MultiSelect = False
        Me.lvwCars.Name = "lvwCars"
        Me.lvwCars.Size = New System.Drawing.Size(499, 194)
        Me.lvwCars.TabIndex = 10
        Me.ttCarInventory.SetToolTip(Me.lvwCars, "List of Registered Vehicles")
        Me.lvwCars.UseCompatibleStateImageBehavior = False
        Me.lvwCars.View = System.Windows.Forms.View.Details
        '
        'colNew
        '
        Me.colNew.Text = "New"
        Me.colNew.Width = 41
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 32
        '
        'colMake
        '
        Me.colMake.Text = "Make"
        Me.colMake.Width = 96
        '
        'colYear
        '
        Me.colYear.Text = "Year"
        Me.colYear.Width = 74
        '
        'colPrice
        '
        Me.colPrice.Text = "Price"
        Me.colPrice.Width = 128
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(199, 521)
        Me.btnEnter.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(100, 28)
        Me.btnEnter.TabIndex = 5
        Me.btnEnter.Text = "&Enter"
        Me.ttCarInventory.SetToolTip(Me.btnEnter, "Enter Vehicle Information")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(307, 521)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(100, 28)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "&Reset"
        Me.ttCarInventory.SetToolTip(Me.btnReset, "Reset The Form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(415, 521)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(100, 28)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.ttCarInventory.SetToolTip(Me.btnExit, "Exit The Form")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'ttCarInventory
        '
        '
        'lblResults
        '
        Me.lblResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResults.Location = New System.Drawing.Point(13, 393)
        Me.lblResults.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblResults.Name = "lblResults"
        Me.lblResults.Size = New System.Drawing.Size(500, 112)
        Me.lblResults.TabIndex = 11
        Me.ttCarInventory.SetToolTip(Me.lblResults, "Input Results")
        '
        'CarInventoryForm
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(529, 564)
        Me.Controls.Add(Me.lblResults)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lvwCars)
        Me.Controls.Add(Me.tbPrice)
        Me.Controls.Add(Me.cmbYear)
        Me.Controls.Add(Me.tbModel)
        Me.Controls.Add(Me.cmbMake)
        Me.Controls.Add(Me.cbNew)
        Me.Controls.Add(Me.lblNew)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMake)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CarInventoryForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMake As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblNew As Label
    Friend WithEvents cbNew As CheckBox
    Friend WithEvents cmbMake As ComboBox
    Friend WithEvents tbModel As TextBox
    Friend WithEvents cmbYear As ComboBox
    Friend WithEvents tbPrice As TextBox
    Friend WithEvents lvwCars As ListView
    Friend WithEvents colNew As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colMake As ColumnHeader
    Friend WithEvents colYear As ColumnHeader
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttCarInventory As ToolTip
    Friend WithEvents lblResults As Label
End Class
