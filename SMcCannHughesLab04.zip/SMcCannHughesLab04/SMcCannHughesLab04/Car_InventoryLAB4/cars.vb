﻿Option Strict On
Public Class cars

    Private Shared carCount As Integer
    Private carIdentificationNumber As Integer = 0
    Private carMake As String = String.Empty
    Private carModel As String = String.Empty
    Private carYear As String = String.Empty
    Private carPrice As String = String.Empty
    Private carNew As Boolean = False

    Public Sub New()

        carCount += 1
        carIdentificationNumber = carCount

    End Sub

    Public Sub New(Make As String, Model As String, Year As String, Price As String, News As Boolean)

        Me.New()

        carMake = Make
        carModel = Model
        carPrice = Price
        carYear = Year
        carNew = News

    End Sub

    Public ReadOnly Property Count() As Integer
        Get
            Return carCount
        End Get
    End Property
    Public ReadOnly Property IdentificationNumber() As Integer
        Get
            Return carIdentificationNumber
        End Get
    End Property

    Public Property News() As Boolean
        Get
            Return carNew
        End Get
        Set(value As Boolean)
            carNew = value
        End Set
    End Property
    Public Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property
    Public Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property
    Public Property Year() As String
        Get
            Return carYear
        End Get
        Set(value As String)
            carYear = value
        End Set
    End Property
    Public Property Price As String
        Get
            Return carPrice
        End Get
        Set(value As String)
            carPrice = value
        End Set
    End Property

    Public Function GetCarInfo() As String

        Return "You vehicle is a" & carYear & " " & carMake & " " & carModel & " that costs " & carPrice & ", " & IIf(carNew = True, "this vehicle is new", "this vehicle is not new").ToString()

    End Function

End Class
