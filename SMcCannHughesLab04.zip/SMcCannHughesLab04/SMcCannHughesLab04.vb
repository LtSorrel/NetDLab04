﻿Option Strict On

'' Author Name:     Sarah McCann-Hughes
'' Project:         Car Inventory
'' Date:            07/09/19
'' Description:     This Application inputs the Makes, Model, Year, Price and Whether the Car is new or not into the inventory list for later                       recall.

Public Class frmCarInventoryForm
    Private carList As New SortedList
    Private currentCarIdentification As String = String.Empty
    Private formEdit As Boolean = False


    Private Sub Reset()

        cbNew.Checked = False
        txtModel.Text = String.Empty
        txtPrice.Text = String.Empty
        cmbMake.SelectedIndex = -1
        cmbYear.SelectedIndex = -1
        lvwCars.Text = String.Empty

    End Sub

    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True
        Dim outputMesssage As String = String.Empty

        If cmbMake.SelectedIndex = -1 Then
            outputMesssage += "Select Your Cars Make"
            returnValue = False
        End If

        If cmbYear.SelectedIndex = -1 Then
            outputMesssage += "Select Your Cars Year"
            returnValue = False
        End If

        If txtModel.Text.Trim.Length = 0 Then
            outputMesssage += "Select Your Cars Model"
            returnValue = False
        End If

        If txtPrice.Text.Trim.Length = 0 Then
            outputMesssage += "Enter Your Cars Price"
            returnValue = False
        End If
        Return returnValue

    End Function
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim car As cars
        Dim carItem As ListViewItem

        If IsValidInput() = True Then
            formEdit = True
            lblResults.Text = "Congradulations!"

            If currentCarIdentification.Trim.Length = 0 Then
                car = New cars(cmbMake.Text, cmbYear.Text, txtModel.Text, txtPrice.Text, cbNew.Checked)
                carList.Add(car.IdentificationNumber.ToString(), car)
            Else
                car = CType(carList.Item(currentCarIdentification), cars)

                car.Make = cmbMake.Text
                car.Model = txtModel.Text
                car.Price = txtPrice.Text
                car.Year = cmbYear.Text
                car.News = cbNew.Checked
            End If

            lvwCars.Items.Clear()

            For Each carEntry As DictionaryEntry In carList
                carItem = New ListViewItem()
                car = CType(carEntry.Value, cars)

                carItem.Checked = car.News
                carItem.SubItems.Add(car.IdentificationNumber.ToString())
                carItem.SubItems.Add(car.Make)
                carItem.SubItems.Add(car.Year)
                carItem.SubItems.Add(car.Price)

                lvwCars.Items.Add(carItem)

            Next carEntry
            Reset()
            formEdit = False

        End If

    End Sub

    Private Sub lvwCars_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCars.SelectedIndexChanged

        Const identificationSubItemIndex As Integer = 1

        currentCarIdentification = lvwCars.Items(lvwCars.FocusedItem.Index).SubItems(identificationSubItemIndex).Text

        Dim car As cars = CType(carList.Item(currentCarIdentification), cars)
        txtModel.Text = car.Model
        txtPrice.Text = car.Price
        cmbMake.Text = car.Make
        cmbYear.Text = car.Year
        cbNew.Checked = car.News

        lblResults.Text = car.GetCarInfo()


    End Sub
End Class


